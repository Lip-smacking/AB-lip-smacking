---
name: dynamic-prompt-planner
description: Diagnose a user's goal and co-create a concise, structured AI prompt using an appropriate ICIO module combination. Use when users want to clarify, design, rewrite, or optimize prompts for commercial, creative, technical, analytical, or complex tasks. Do not use when the user wants the underlying task completed directly rather than a reusable prompt.
display_name: Prompt Planner
description_zh: 将模糊需求整理成精简、可直接复用的 AI 提示词。
description_en: Turn a vague goal into a concise, reusable AI prompt.
version: "3.0.1"
author: Haiyannnn
license: MIT
metadata:
  author: Haiyannnn
  version: "3.0.1"
  language: zh-CN
---

# Prompt Planner

把模糊需求诊断为清晰任务，并用最少但足够的 ICIO 模块共建一份可直接复用的提示词。默认降低用户的输入与理解成本，不为了展示框架而堆叠模块。

## 使用边界

- 用户想获得、优化或学习编写提示词时使用本 Skill。
- 用户只想直接完成写作、分析、编程等任务时，直接执行任务，不要强行转入提示词教学。
- 用户已经提供充分信息时直接构建，不重复询问。

## 两种交互模式

### 快速模式（默认）

根据已有信息完成诊断，只集中询问一次真正影响结果的缺失项；能合理推断的内容不追问。随后直接选择框架并交付提示词。

### 共建模式

仅当用户明确希望逐步学习、共同填写或深入梳理时启用。按“战略定位 → 执行细节 → 交付标准”逐步提问，每轮只问当前必要问题。

## 框架选择

从以下四类中选择最精简、最匹配的一类：

- **人格魅力型**：依赖人格、语气、风格和示例的创作、文案、角色扮演与风格模仿。
- **逻辑执行型**：代码、自动化、报告和标准化交付等强调流程、约束与格式的任务。
- **战略分析型**：市场、商业、竞品和决策任务，强调背景、挑战、问题与备选方案。
- **全能大师型**：创意、逻辑和战略同时重要的高复杂度任务；只有确有必要时使用。

默认直接采用最佳方案并简述理由。只有两个方案各有明显取舍时，才向用户提供两个选项，不机械地要求每位用户先选择。

详细模块定义、选择标准与示例见 [references/icio-frameworks.md](references/icio-frameworks.md)。仅在需要完整教学、复杂诊断或解释框架差异时读取。

## 工作流

1. **诊断需求**：识别最终交付物、使用目的、受众、输入背景、成功标准和关键限制。
2. **补齐关键信息**：只问会显著改变提示词的问题；优先用一组简短问题一次收集。
3. **选择模块**：保留真正有用的模块，删除重复或无贡献的模块。
4. **构建提示词**：把用户信息转成明确任务、必要上下文、执行要求、约束和输出格式；每个要求应可执行、可验证。
5. **质量检查**：确认提示词自包含、没有矛盾、没有虚构用户未提供的事实，并且复杂度与任务风险相称。
6. **交付**：用一个代码块给出最终提示词；必要时附一段简短的框架选择理由和使用方法。

## 低成本提问原则

- 简单任务通常只需：目标、输入、输出格式、关键约束。
- 不要逐个询问所有 ICIO 模块；缺失但不关键的模块直接省略。
- 不要求用户理解术语后才能继续；必要时用普通语言提问。
- 对模糊答案先做合理整理，再针对唯一关键歧义追问。
- 如果用户要求“直接给结果”，停止教学，直接生成最佳可用提示词。

## 交付格式

默认按以下顺序输出，用户指定格式时服从用户要求：

1. 一句话诊断与所选框架。
2. 可直接复制的最终提示词代码块。
3. 最多三条使用或替换提示。

最终提示词应独立可用，不依赖本次对话中的隐含信息。除非用户明确要求，不输出冗长的模块讲解或“赋能反思”。

## 约束

- 不把示例内容当成用户事实或当前授权。
- 不为“完整”而添加无关角色、流程、格式或限制。
- 不承诺无法验证的效果，不伪造数据、案例或来源。
- 不把一种固定框架强加给所有任务；复杂度越低，提示词越精简。
